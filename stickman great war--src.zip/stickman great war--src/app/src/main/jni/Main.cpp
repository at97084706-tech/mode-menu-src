#include <jni.h>
#include <pthread.h>
#include <dlfcn.h>
#include <cstring>
#include <unistd.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"

#define targetLibName OBFUSCATE("libil2cpp.so")
#include "Includes/Macros.h"

// --- Global Feature Variables ---
bool GodMod = false;
bool FreeIAP = false;

// --- Helper function to get base address if Utils.h is missing it ---
uintptr_t get_base_address(const char* name) {
    uintptr_t base = 0;
    char line[512];
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, name)) {
            base = (uintptr_t)strtoul(line, NULL, 16);
            break;
        }
    }
    fclose(f);
    return base;
}

// --- God Mode Hook ---
void (*old_gethit)(void *instance, float dmg, bool isKnockBack, bool isPush, float timeLoopHit, bool isHitByCombo);
void gethit(void *instance, float dmg, bool isKnockBack, bool isPush, float timeLoopHit, bool isHitByCombo) {
    if (instance != NULL && GodMod) {
        // Offset 0x29 isPlayer check
        bool isPlayer = *(bool *)((uintptr_t)instance + 0x29);
        if (isPlayer) return; 
    }
    old_gethit(instance, dmg, isKnockBack, isPush, timeLoopHit, isHitByCombo);
}

// --- Instant Purchase Redirect ---

// Success method definition (RVA: 0x1A34768)
void (*Buy_Success)(void *instance, void *productName) = nullptr;

// Hook BuyProductID (RVA: 0x1A33820)
void (*old_BuyProductID)(void *instance, void *productId);
void BuyProductID(void *instance, void *productId) {
    if (FreeIAP && instance != nullptr && productId != nullptr) {
        LOGI("IAP Bypass: Intercepted request, forcing success...");
        if (Buy_Success) {
            Buy_Success(instance, productId);
            return; // Don't call original
        }
    }
    old_BuyProductID(instance, productId);
}

// --- Hack Thread ---
void *hack_thread(void *) {
    // Wait for the library to load
    while (get_base_address(targetLibName) == 0) {
        sleep(1);
    }

    uintptr_t libBase = get_base_address(targetLibName);

#if defined(__aarch64__)  
    // 1. Hook God Mode
    HOOK_LIB("libil2cpp.so", "0x1964048", gethit, old_gethit);

    // 2. Hook Purchase Request
    HOOK_LIB("libil2cpp.so", "0x1A33820", BuyProductID, old_BuyProductID);

    // 3. Assign the address for the Success function
    Buy_Success = (void (*)(void *, void *))(libBase + 0x1A34768);
#endif

    LOGI("Mod Menu: Hooks Applied Successfully");
    return NULL;
}

// --- Menu UI Logic ---

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    const char *features[] = {
            OBFUSCATE("Collapse_GOD MODE"),
            OBFUSCATE("15_CollapseAdd_Toggle_GOD MODE"),
			OBFUSCATE("Collapse_STORE"),
            OBFUSCATE("16_CollapseAdd_Toggle_FREE SHOPPING")
    };

    int Total_Feature = (sizeof features / sizeof features[0]);
    jobjectArray ret = (jobjectArray)env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")), env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, jint value, jboolean boolean, jstring str) {
    switch (featNum) {
        case 15: GodMod = boolean; break;
        case 16: FreeIAP = boolean; break;
    }
}

__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}
/*
OFFSETS LOCATIONS
 <------------------>
  public class IAPManager : MonoBehaviour, IDisposable // TypeDefIndex: 2821
  public void Buy_Success(string name) 
  private void BuyProductID(string productId)
  
  <----------------->
  
  public class BaseController : MonoBehaviour // TypeDefIndex: 1768
  public virtual void GetHit(float dmg, bool isKnockBack = False, bool isPush = False, float timeLoopHit = 0, bool isHitByCombo = True)
  public bool isPlayer; // 0x29


*/

// --- JNI Registration ---

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("Background"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Background)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz) return JNI_ERR;
    return (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) == 0) ? JNI_OK : JNI_ERR;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz) return JNI_ERR;
    return (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) == 0) ? JNI_OK : JNI_ERR;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz) return JNI_ERR;
    return (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) == 0) ? JNI_OK : JNI_ERR;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0 || RegisterPreferences(env) != 0 || RegisterMain(env) != 0) return JNI_ERR;
    return JNI_VERSION_1_6;
}

